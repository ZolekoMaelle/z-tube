# Zentube
application GUI  pour télécharger des vidéos sur youtube facilement .

![logo zentube](https://user-images.githubusercontent.com/84296565/166245379-50df95f3-ff76-4138-8f68-36920bf597cf.png)

--> Installer les prerequis:
python -m pip install -r requirements.txt 
![demo 1](https://user-images.githubusercontent.com/84296565/166246519-3afaf07f-567b-4bec-9b86-a1ce9303b7df.PNG)
![demo 2](https://user-images.githubusercontent.com/84296565/166246647-add1b5ca-355a-441d-a7ee-891ef8eadf11.PNG)


[+]instructions



--> ETAPE 1:
        Identifier et récuperer le lien du flux video donc voulez télécharger depuis la plateforme Youtube.com
        
   
![zentube1_0_1](https://user-images.githubusercontent.com/84296565/167687199-c9aaad8b-fe26-49ef-aa45-7a7d5ac9b6ae.PNG)

--> ETAPE 2:
        Coller le lien URL de la vidéo depuis le champs de lien
        
   ![zentube1_0_3](https://user-images.githubusercontent.com/84296565/167687327-36a2fe46-0af3-4951-8749-db2cf9b2c2f8.PNG)



--> ETAPE 3:
      Cliquer sur le boutton Analyse pour analyser le lien correspondant au flux vidéo
      

      
   ![zentube1_0_2](https://user-images.githubusercontent.com/84296565/167687454-d63c3c35-745b-4b7f-97b4-a418aa2505f0.PNG)

      
--> ETAPE 4:
      Après analayse du lien, cliquer le boutton de téléchargement pour enrégistrer votre vidéo.
      
      
   NB/ les vidéos téléchargées seront stockées depuis le repertoire ../dowloaded/
   
   
 ![demo 4](https://user-images.githubusercontent.com/84296565/166246925-d8b87023-4dd7-4168-b69e-01d924438d9a.PNG)

   
![demo 5](https://user-images.githubusercontent.com/84296565/166246891-8429ac0c-2755-4dcd-ab51-880bf7d056fd.PNG)


